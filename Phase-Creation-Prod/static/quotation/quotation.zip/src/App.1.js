import React, { useState, useEffect } from 'react';
import Button from '@atlaskit/button';
import TextField from '@atlaskit/textfield';
import styled from 'styled-components';
import fallbackJson from './Headliner.json';

// Fallback data
const fallbackData = fallbackJson.activities || {
  "Headliner Fitment": {
    "NORMAL ROOF": {
      "Proto": 2,
      "Serie": 1,
      "subactivity": {
        "Headliner Bracket Fitment": { "Proto": 2, "Serie": 1 },
        "Parcel Tray Bracket Fitment": { "Proto": 2, "Serie": 1 },
        "Clip Fitment": { "Proto": 2, "Serie": 1 },
        "Headliner Fitment": { "Proto": 2, "Serie": 1 }
      }
    },
    "PANO ROOF": { "Proto": 2, "Serie": 1 },
    "SUN ROOF": { "Proto": 2, "Serie": 1 }
  },
  "QC Check": {
    "NORMAL ROOF": {
      "Proto": 1,
      "Serie": 1,
      "subactivity": {
        "QC Check": { "Proto": 1, "Serie": 1 }
      }
    }
  }
};

// Styled Components
const Container = styled.div`
  padding: 40px;
  margin: 20px;
  background-color: #f4f5f7;
  border-radius: 12px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  min-height: 100vh;
  box-sizing: border-box;
`;

const Header = styled.h2`
  margin-bottom: 24px;
  color: #172b4d;
`;

const RoofSelector = styled.div`
  margin-bottom: 24px;
  display: flex;
  gap: 12px;
  align-items: flex-end;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
`;

const Th = styled.th`
  text-align: left;
  background: #ebecf0;
  color: #253858;
  padding: 12px 16px;
  font-size: 14px;
  font-weight: 600;
  border-bottom: 1px solid #dfe1e6;
`;

const Td = styled.td`
  padding: 12px 16px;
  font-size: 14px;
  border-bottom: 1px solid #f0f0f0;

  &:first-child {
    font-weight: 500;
    color: #172b4d;
  }
`;

const Indent = styled.span`
  padding-left: 24px;
  display: inline-block;
  color: #5e6c84;
`;

const StyledTextField = styled(TextField)`
  input {
    border-radius: 6px !important;
    height: 36px;
  }
`;

const Tr = styled.tr`
  &:hover {
    background-color: #f9fafc;
  }
`;

const App = () => {
  const [roofType, setRoofType] = useState('NORMAL ROOF');
  const [data, setData] = useState({});

  useEffect(() => {
    setData(fallbackData);
  }, []);

  const handleChange = (activityKey, subKey, field, value) => {
    const updated = { ...data };
    if (subKey) {
      updated[activityKey][roofType].subactivity[subKey][field] = parseInt(value || 0);
    } else {
      updated[activityKey][roofType][field] = parseInt(value || 0);
    }
    setData(updated);
  };

  const renderTableRows = () => {
    const rows = [];

    Object.entries(data).forEach(([activityKey, activity]) => {
      const roofData = activity[roofType];
      if (!roofData) return;

      const hasSub = roofData.subactivity && Object.keys(roofData.subactivity).length > 0;

      rows.push(
        <Tr key={activityKey}>
          <Td><strong>{activityKey}</strong></Td>
          <Td>{!hasSub && (
            <StyledTextField
              type="number"
              value={roofData.Proto}
              onChange={(e) => handleChange(activityKey, null, 'Proto', e.target.value)}
            />
          )}</Td>
          <Td>{!hasSub && (
            <StyledTextField
              type="number"
              value={roofData.Serie}
              onChange={(e) => handleChange(activityKey, null, 'Serie', e.target.value)}
            />
          )}</Td>
        </Tr>
      );

      if (hasSub) {
        Object.entries(roofData.subactivity).forEach(([subKey, sub]) => {
          rows.push(
            <Tr key={`${activityKey}-${subKey}`}>
              <Td><Indent>└─ {subKey}</Indent></Td>
              <Td>
                <StyledTextField
                  type="number"
                  value={sub.Proto}
                  onChange={(e) => handleChange(activityKey, subKey, 'Proto', e.target.value)}
                />
              </Td>
              <Td>
                <StyledTextField
                  type="number"
                  value={sub.Serie}
                  onChange={(e) => handleChange(activityKey, subKey, 'Serie', e.target.value)}
                />
              </Td>
            </Tr>
          );
        });
      }
    });

    return rows;
  };

  return (
    <Container>
      <Header>Modify Proto & Serie Loops</Header>

      <RoofSelector>
        <TextField
          label="Roof Type"
          value={roofType}
          onChange={(e) => setRoofType(e.target.value)}
        />
        <Button appearance="primary" onClick={() => console.log('Updated JSON:', data)}>
          Save Changes
        </Button>
      </RoofSelector>

      <Table>
        <thead>
          <tr>
            <Th>Activity / Subactivity</Th>
            <Th>Proto</Th>
            <Th>Serie</Th>
          </tr>
        </thead>
        <tbody>{renderTableRows()}</tbody>
      </Table>
    </Container>
  );
};

export default App;
