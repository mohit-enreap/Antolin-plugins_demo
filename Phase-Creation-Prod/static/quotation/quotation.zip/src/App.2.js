import React, { useState, useEffect } from 'react';
import Button from '@atlaskit/button';
import TextField from '@atlaskit/textfield';
import Checkbox from '@atlaskit/checkbox';
import styled from 'styled-components';
import fallbackJson from './Headliner.json';

// Fallback data
const fallbackData = fallbackJson.activities || {};

const nonProductPartKeys = ['extraWorkLoop', 'reWorkLoop', 'standardLoop', 'checked', 'order'];

// Styled Components
const Container = styled.div`
  padding: 40px;
  margin: 20px;
  background-color: #f4f5f7;
  border-radius: 12px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  min-height: 100vh;
  box-sizing: border-box;
`;

const Header = styled.h2`
  margin-bottom: 24px;
  color: #172b4d;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
`;

const Th = styled.th`
  text-align: left;
  background: #ebecf0;
  color: #253858;
  padding: 12px 16px;
  font-size: 14px;
  font-weight: 600;
  border-bottom: 1px solid #dfe1e6;
`;

const Td = styled.td`
  padding: 12px 16px;
  font-size: 14px;
  border-bottom: 1px solid #f0f0f0;

  &:first-child {
    font-weight: 500;
    color: #172b4d;
  }
`;

const Indent = styled.span`
  padding-left: 24px;
  display: inline-block;
  color: #5e6c84;
`;

const StyledTextField = styled(TextField)`
  input {
    border-radius: 6px !important;
    height: 36px;
  }
`;

const Tr = styled.tr`
  &:hover {
    background-color: #f9fafc;
  }
`;

const App = () => {
  const [data, setData] = useState({});

  useEffect(() => {
    setData(fallbackData);
  }, []);

  const handleChange = (activityKey, subKey, field, value) => {
    const updated = { ...data };
    const numericValue = parseInt(value || 0);

    const activity = updated[activityKey];
    if (!activity) return;

    Object.entries(activity).forEach(([partKey, partData]) => {
      if (nonProductPartKeys.includes(partKey)) return;

      if (subKey) {
        if (partData?.subactivity?.[subKey]) {
          partData.subactivity[subKey][field] = numericValue;
        }
      } else {
        if (partData?.hasOwnProperty(field)) {
          partData[field] = numericValue;
        }
      }
    });

    setData(updated);
  };

  const handleCheckboxChange = (activityKey) => {
    const updated = { ...data };
    updated[activityKey].checked = !updated[activityKey].checked;
    setData(updated);
  };

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify({ activities: data }, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'updated_activities.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderTableRows = () => {
    const rows = [];

    Object.entries(data).forEach(([activityKey, activity]) => {
      const samplePartEntry = Object.entries(activity).find(
        ([key]) => !nonProductPartKeys.includes(key)
      );

      if (!samplePartEntry) return;

      const [, partData] = samplePartEntry;
      const hasSub = partData.subactivity && Object.keys(partData.subactivity).length > 0;

      rows.push(
        <Tr key={`${activityKey}`}>
          <Td>
            <Checkbox
              isChecked={activity.checked}
              onChange={() => handleCheckboxChange(activityKey)}
              label={activityKey}
            />
          </Td>
          <Td>{!hasSub && (
            <StyledTextField
              type="number"
              value={partData.Proto}
              onChange={(e) => handleChange(activityKey, null, 'Proto', e.target.value)}
            />
          )}</Td>
          <Td>{!hasSub && (
            <StyledTextField
              type="number"
              value={partData.Serie}
              onChange={(e) => handleChange(activityKey, null, 'Serie', e.target.value)}
            />
          )}</Td>
        </Tr>
      );

      if (hasSub) {
        Object.entries(partData.subactivity).forEach(([subKey, sub]) => {
          rows.push(
            <Tr key={`${activityKey}-${subKey}`}>
              <Td><Indent>└─ {subKey}</Indent></Td>
              <Td>
                <StyledTextField
                  type="number"
                  value={sub.Proto}
                  onChange={(e) => handleChange(activityKey, subKey, 'Proto', e.target.value)}
                />
              </Td>
              <Td>
                <StyledTextField
                  type="number"
                  value={sub.Serie}
                  onChange={(e) => handleChange(activityKey, subKey, 'Serie', e.target.value)}
                />
              </Td>
            </Tr>
          );
        });
      }
    });

    return rows;
  };

  return (
    <Container>
      <Header>Modify Proto & Serie Loops</Header>

      <Button appearance="primary" onClick={handleDownload}>
        Save Changes
      </Button>

      <Table>
        <thead>
          <tr>
            <Th>Activity</Th>
            <Th>Proto</Th>
            <Th>Serie</Th>
          </tr>
        </thead>
        <tbody>{renderTableRows()}</tbody>
      </Table>
    </Container>
  );
};

export default App;
