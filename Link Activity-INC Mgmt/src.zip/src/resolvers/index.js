import Resolver from "@forge/resolver";
import api, { route } from "@forge/api";

const resolver = new Resolver();

resolver.define("getIssuesByJQL", async ({ payload }) => {
  const { jql } = payload; // Extract JQL from the payload

  if (!jql) {
    return { error: "JQL query is not provided in the payload" };
  }
console.log(jql)
  try {
    let allIssues = [];
    let startAt = 0;
    const maxResults = 1000; // Adjust based on API limits

    while (true) {
      const response = await api.asApp().requestJira(
        route`/rest/api/2/search?jql=type=Project&startAt=${startAt}&maxResults=${maxResults}`
      );
// console.log(`/rest/api/2/search?jql=${encodeURIComponent(jql)}&startAt=${startAt}&maxResults=${maxResults}`)
      if (!response.ok) {
        return { error: `Failed to fetch issues. Status: ${response.status}` };
      }

      const data = await response.json();
      console.log(response)
      allIssues = allIssues.concat(data.issues);
console.log(allIssues)
      if (data.issues.length < maxResults) {
        break; // No more issues to fetch
      }

      startAt += maxResults;
    }

    return { issues: allIssues };
  } catch (error) {
    return { error: `Error fetching issues: ${error.message}` };
  }
});

// Export all resolver definitions
export const handler = resolver.getDefinitions();
